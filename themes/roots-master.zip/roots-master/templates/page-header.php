<div class="page-header">
  <h1>
    <?php echo roots_title(); ?>
  </h1>
</div>